//
//  ModuleAppleHealth.h
//  ModuleAppleHealth
//
//  Created by Florian on 14.10.19.
//  Copyright © 2019 Undgesund. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ModuleAppleHealth.
FOUNDATION_EXPORT double ModuleAppleHealthVersionNumber;

//! Project version string for ModuleAppleHealth.
FOUNDATION_EXPORT const unsigned char ModuleAppleHealthVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ModuleAppleHealth/PublicHeader.h>


