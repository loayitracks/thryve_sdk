//
//  ModuleRecognition.h
//  ModuleRecognition
//
//  Created by Florian on 14.10.19.
//  Copyright © 2019 Undgesund. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ModuleRecognition.
FOUNDATION_EXPORT double ModuleRecognitionVersionNumber;

//! Project version string for ModuleRecognition.
FOUNDATION_EXPORT const unsigned char ModuleRecognitionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ModuleRecognition/PublicHeader.h>


